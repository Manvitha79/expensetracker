import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DashboardNav } from "@/components/dashboard-nav"
import { CategoriesList } from "@/components/categories-list"
import { CategoryGraph } from "@/components/category-graph"

export default async function CategoriesPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Categories</h1>
          <p className="text-muted-foreground">Manage your expense categories and track spending by category</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <CategoriesList userId={user.id} />
          <CategoryGraph userId={user.id} />
        </div>
      </main>
    </div>
  )
}

import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DashboardNav } from "@/components/dashboard-nav"
import { ExpenseBoard } from "@/components/expense-board"
import { ExpenseManagement } from "@/components/expense-management"
import { MonthlyYearlyChart } from "@/components/monthly-yearly-chart"
import { SpendingReminders } from "@/components/spending-reminders"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Initialize default categories if user doesn't have any
  const { data: categories } = await supabase.from("categories").select("id").eq("user_id", user.id).limit(1)

  if (!categories || categories.length === 0) {
    await supabase.rpc("initialize_default_categories", {
      user_id_param: user.id,
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">Track and manage your expenses</p>
        </div>

        <div className="grid gap-6 mb-6">
          <SpendingReminders userId={user.id} />
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2">
            <ExpenseBoard userId={user.id} />
          </div>
          <div>
            <ExpenseManagement userId={user.id} />
          </div>
        </div>

        <div className="grid gap-6">
          <MonthlyYearlyChart userId={user.id} />
        </div>
      </main>
    </div>
  )
}

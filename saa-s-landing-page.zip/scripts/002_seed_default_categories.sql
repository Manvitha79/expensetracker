-- This script adds some default categories for each user
-- Note: This should be run after user signup, or you can manually add categories
-- For now, we'll create a function that users can call to initialize default categories

CREATE OR REPLACE FUNCTION public.initialize_default_categories(user_id_param UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert default categories only if user has no categories
  IF NOT EXISTS (SELECT 1 FROM public.categories WHERE user_id = user_id_param) THEN
    INSERT INTO public.categories (user_id, name, budget, color) VALUES
      (user_id_param, 'Food & Dining', 500.00, '#ef4444'),
      (user_id_param, 'Transportation', 200.00, '#3b82f6'),
      (user_id_param, 'Shopping', 300.00, '#8b5cf6'),
      (user_id_param, 'Entertainment', 150.00, '#ec4899'),
      (user_id_param, 'Bills & Utilities', 400.00, '#f59e0b'),
      (user_id_param, 'Healthcare', 200.00, '#10b981'),
      (user_id_param, 'Other', 100.00, '#6b7280');
  END IF;
END;
$$;

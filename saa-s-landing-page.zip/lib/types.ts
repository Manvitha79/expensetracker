export interface Profile {
  id: string
  email: string
  full_name: string | null
  created_at: string
}

export interface Category {
  id: string
  user_id: string
  name: string
  budget: number
  color: string
  created_at: string
}

export interface Expense {
  id: string
  user_id: string
  category_id: string | null
  amount: number
  description: string | null
  date: string
  created_at: string
}

export interface ExpenseWithCategory extends Expense {
  category: Category | null
}

export interface CategoryWithExpenses extends Category {
  total_spent: number
  expense_count: number
}

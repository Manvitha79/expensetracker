"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts"

interface CategoryGraphProps {
  userId: string
}

interface CategoryData {
  name: string
  budget: number
  spent: number
  color: string
}

export function CategoryGraph({ userId }: CategoryGraphProps) {
  const [data, setData] = useState<CategoryData[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setIsLoading(true)
    const supabase = createClient()

    const { data: categories } = await supabase.from("categories").select("*").eq("user_id", userId).order("name")

    const { data: expenses } = await supabase.from("expenses").select("category_id, amount").eq("user_id", userId)

    if (categories && expenses) {
      const categoryTotals = new Map<string, number>()
      expenses.forEach((expense) => {
        if (expense.category_id) {
          const current = categoryTotals.get(expense.category_id) || 0
          categoryTotals.set(expense.category_id, current + Number(expense.amount))
        }
      })

      const chartData = categories.map((cat) => ({
        name: cat.name,
        budget: Number(cat.budget),
        spent: categoryTotals.get(cat.id) || 0,
        color: cat.color,
      }))

      setData(chartData)
    }
    setIsLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Category Spending Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-[400px] flex items-center justify-center text-muted-foreground">Loading data...</div>
        ) : data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} fontSize={12} />
              <YAxis />
              <Tooltip
                formatter={(value: number) =>
                  new Intl.NumberFormat("en-US", {
                    style: "currency",
                    currency: "USD",
                  }).format(value)
                }
              />
              <Legend />
              <Line type="monotone" dataKey="budget" stroke="#6b7280" strokeWidth={2} name="Budget" dot={{ r: 4 }} />
              <Line
                type="monotone"
                dataKey="spent"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                name="Spent"
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-muted-foreground">
            No data available. Add categories and expenses to see the graph.
          </div>
        )}
      </CardContent>
    </Card>
  )
}

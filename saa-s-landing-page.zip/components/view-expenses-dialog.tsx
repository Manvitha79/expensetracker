"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { createClient } from "@/lib/supabase/client"
import { formatCurrency } from "@/lib/utils"
import type { ExpenseWithCategory } from "@/lib/types"
import { format } from "date-fns"

interface ViewExpensesDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  userId: string
}

export function ViewExpensesDialog({ open, onOpenChange, userId }: ViewExpensesDialogProps) {
  const [expenses, setExpenses] = useState<ExpenseWithCategory[]>([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (open) {
      fetchExpenses()
    }
  }, [open])

  const fetchExpenses = async () => {
    setIsLoading(true)
    const supabase = createClient()
    const { data } = await supabase
      .from("expenses")
      .select(`
        *,
        category:categories(*)
      `)
      .eq("user_id", userId)
      .order("date", { ascending: false })
      .limit(50)

    if (data) setExpenses(data as unknown as ExpenseWithCategory[])
    setIsLoading(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Recent Expenses</DialogTitle>
          <DialogDescription>View your recent expense transactions</DialogDescription>
        </DialogHeader>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Loading expenses...</div>
        ) : expenses.length > 0 ? (
          <div className="space-y-3">
            {expenses.map((expense) => (
              <div key={expense.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {expense.category && (
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: expense.category.color }} />
                    )}
                    <span className="font-medium">{expense.category?.name || "Uncategorized"}</span>
                  </div>
                  {expense.description && <p className="text-sm text-muted-foreground">{expense.description}</p>}
                  <p className="text-xs text-muted-foreground mt-1">{format(new Date(expense.date), "MMM dd, yyyy")}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold">{formatCurrency(Number(expense.amount))}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            No expenses found. Add your first expense to get started!
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"
import { Pencil } from "lucide-react"
import { useRouter } from "next/navigation"

interface EditBudgetDialogProps {
  userId: string
  categories: Array<{ id: string; name: string; budget: number }>
}

export function EditBudgetDialog({ userId, categories }: EditBudgetDialogProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [budgets, setBudgets] = useState<Record<string, string>>(
    categories.reduce((acc, cat) => ({ ...acc, [cat.id]: cat.budget.toString() }), {}),
  )
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    const supabase = createClient()

    try {
      // Update each category budget
      for (const [categoryId, budgetValue] of Object.entries(budgets)) {
        await supabase
          .from("categories")
          .update({ budget: Number.parseFloat(budgetValue) || 0 })
          .eq("id", categoryId)
          .eq("user_id", userId)
      }

      setOpen(false)
      router.refresh()
    } catch (error) {
      console.error("Error updating budgets:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleBudgetChange = (categoryId: string, value: string) => {
    setBudgets((prev) => ({ ...prev, [categoryId]: value }))
  }

  const totalBudget = Object.values(budgets).reduce((sum, val) => sum + (Number.parseFloat(val) || 0), 0)

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Pencil className="h-4 w-4 mr-2" />
          Edit Budgets
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Edit Category Budgets</DialogTitle>
            <DialogDescription>Update the budget amounts for each category</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {categories.map((category) => (
              <div key={category.id} className="space-y-2">
                <Label htmlFor={`budget-${category.id}`}>{category.name}</Label>
                <Input
                  id={`budget-${category.id}`}
                  type="number"
                  step="0.01"
                  min="0"
                  value={budgets[category.id]}
                  onChange={(e) => handleBudgetChange(category.id, e.target.value)}
                  placeholder="0.00"
                />
              </div>
            ))}
            <div className="pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total Budget:</span>
                <span className="text-xl font-bold">
                  {new Intl.NumberFormat("en-US", {
                    style: "currency",
                    currency: "USD",
                  }).format(totalBudget)}
                </span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle, TrendingUp } from "lucide-react"
import { formatCurrency } from "@/lib/utils"
import { startOfMonth, endOfMonth, format, subMonths } from "date-fns"

interface SpendingRemindersProps {
  userId: string
}

interface HighSpendingAlert {
  type: "month" | "category"
  title: string
  description: string
}

export async function SpendingReminders({ userId }: SpendingRemindersProps) {
  const supabase = await createClient()
  const alerts: HighSpendingAlert[] = []

  // Get current month expenses
  const now = new Date()
  const currentMonthStart = startOfMonth(now)
  const currentMonthEnd = endOfMonth(now)

  const { data: currentMonthExpenses } = await supabase
    .from("expenses")
    .select("amount, date")
    .eq("user_id", userId)
    .gte("date", currentMonthStart.toISOString().split("T")[0])
    .lte("date", currentMonthEnd.toISOString().split("T")[0])

  const currentMonthTotal = currentMonthExpenses?.reduce((sum, e) => sum + Number(e.amount), 0) || 0

  // Get last month expenses
  const lastMonthStart = startOfMonth(subMonths(now, 1))
  const lastMonthEnd = endOfMonth(subMonths(now, 1))

  const { data: lastMonthExpenses } = await supabase
    .from("expenses")
    .select("amount")
    .eq("user_id", userId)
    .gte("date", lastMonthStart.toISOString().split("T")[0])
    .lte("date", lastMonthEnd.toISOString().split("T")[0])

  const lastMonthTotal = lastMonthExpenses?.reduce((sum, e) => sum + Number(e.amount), 0) || 0

  // Check if current month spending is significantly higher
  if (lastMonthTotal > 0 && currentMonthTotal > lastMonthTotal * 1.2) {
    const percentIncrease = ((currentMonthTotal - lastMonthTotal) / lastMonthTotal) * 100
    alerts.push({
      type: "month",
      title: "High Spending Alert",
      description: `Your spending this month (${formatCurrency(
        currentMonthTotal,
      )}) is ${percentIncrease.toFixed(0)}% higher than last month (${formatCurrency(lastMonthTotal)}).`,
    })
  }

  // Check for categories exceeding budget
  const { data: categories } = await supabase.from("categories").select("*").eq("user_id", userId)

  const { data: categoryExpenses } = await supabase
    .from("expenses")
    .select("category_id, amount")
    .eq("user_id", userId)
    .gte("date", currentMonthStart.toISOString().split("T")[0])
    .lte("date", currentMonthEnd.toISOString().split("T")[0])

  if (categories && categoryExpenses) {
    const categoryTotals = new Map<string, number>()
    categoryExpenses.forEach((expense) => {
      if (expense.category_id) {
        const current = categoryTotals.get(expense.category_id) || 0
        categoryTotals.set(expense.category_id, current + Number(expense.amount))
      }
    })

    categories.forEach((category) => {
      const spent = categoryTotals.get(category.id) || 0
      const budget = Number(category.budget)

      if (spent > budget) {
        const percentOver = ((spent - budget) / budget) * 100
        alerts.push({
          type: "category",
          title: `Budget Exceeded: ${category.name}`,
          description: `You've spent ${formatCurrency(
            spent,
          )}, which is ${percentOver.toFixed(0)}% over your budget of ${formatCurrency(budget)}.`,
        })
      } else if (spent > budget * 0.8) {
        const percentUsed = (spent / budget) * 100
        alerts.push({
          type: "category",
          title: `Budget Warning: ${category.name}`,
          description: `You've used ${percentUsed.toFixed(0)}% of your ${formatCurrency(
            budget,
          )} budget with ${formatCurrency(spent)} spent.`,
        })
      }
    })
  }

  // Find highest spending month in last 6 months
  const sixMonthsAgo = subMonths(now, 6)
  const { data: recentExpenses } = await supabase
    .from("expenses")
    .select("date, amount")
    .eq("user_id", userId)
    .gte("date", sixMonthsAgo.toISOString().split("T")[0])
    .order("date")

  if (recentExpenses && recentExpenses.length > 0) {
    const monthlyTotals = new Map<string, number>()
    recentExpenses.forEach((expense) => {
      const month = format(new Date(expense.date), "MMM yyyy")
      const current = monthlyTotals.get(month) || 0
      monthlyTotals.set(month, current + Number(expense.amount))
    })

    let highestMonth = ""
    let highestAmount = 0
    monthlyTotals.forEach((amount, month) => {
      if (amount > highestAmount) {
        highestAmount = amount
        highestMonth = month
      }
    })

    if (highestMonth && format(now, "MMM yyyy") === highestMonth) {
      alerts.push({
        type: "month",
        title: "Peak Spending Month",
        description: `${highestMonth} is your highest spending month in the last 6 months with ${formatCurrency(
          highestAmount,
        )} in expenses.`,
      })
    }
  }

  if (alerts.length === 0) {
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          Spending Alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {alerts.map((alert, index) => (
          <Alert key={index} variant={alert.type === "month" ? "default" : "destructive"}>
            <TrendingUp className="h-4 w-4" />
            <AlertTitle>{alert.title}</AlertTitle>
            <AlertDescription>{alert.description}</AlertDescription>
          </Alert>
        ))}
      </CardContent>
    </Card>
  )
}

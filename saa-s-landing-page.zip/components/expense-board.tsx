import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCurrency } from "@/lib/utils"
import { EditBudgetDialog } from "@/components/edit-budget-dialog"

interface ExpenseBoardProps {
  userId: string
}

export async function ExpenseBoard({ userId }: ExpenseBoardProps) {
  const supabase = await createClient()

  // Get all categories with their budgets
  const { data: categories } = await supabase.from("categories").select("*").eq("user_id", userId).order("name")

  // Get expenses grouped by category
  const { data: expenses } = await supabase.from("expenses").select("category_id, amount").eq("user_id", userId)

  // Calculate total spent per category
  const categoryTotals = new Map<string, number>()
  expenses?.forEach((expense) => {
    if (expense.category_id) {
      const current = categoryTotals.get(expense.category_id) || 0
      categoryTotals.set(expense.category_id, current + Number(expense.amount))
    }
  })

  // Calculate totals
  const totalBudget = categories?.reduce((sum, cat) => sum + Number(cat.budget), 0) || 0
  const totalSpent = Array.from(categoryTotals.values()).reduce((sum, val) => sum + val, 0)

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Expense Overview</CardTitle>
          {categories && categories.length > 0 && <EditBudgetDialog userId={userId} categories={categories} />}
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6 grid grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-muted">
            <p className="text-sm text-muted-foreground mb-1">Total Budget</p>
            <p className="text-2xl font-bold">{formatCurrency(totalBudget)}</p>
          </div>
          <div className="p-4 rounded-lg bg-muted">
            <p className="text-sm text-muted-foreground mb-1">Total Spent</p>
            <p className="text-2xl font-bold">{formatCurrency(totalSpent)}</p>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold text-sm">Categories</h3>
          {categories && categories.length > 0 ? (
            <div className="space-y-3">
              {categories.map((category) => {
                const spent = categoryTotals.get(category.id) || 0
                const budget = Number(category.budget)
                const percentage = budget > 0 ? (spent / budget) * 100 : 0

                return (
                  <div key={category.id} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full" style={{ backgroundColor: category.color }} />
                        <span className="font-medium">{category.name}</span>
                      </div>
                      <span className="text-muted-foreground">
                        {formatCurrency(spent)} / {formatCurrency(budget)}
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full transition-all"
                        style={{
                          width: `${Math.min(percentage, 100)}%`,
                          backgroundColor: percentage > 100 ? "hsl(var(--destructive))" : category.color,
                        }}
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No categories found. Add categories to start tracking expenses.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

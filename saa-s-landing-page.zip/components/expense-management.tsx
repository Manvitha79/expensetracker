"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PlusCircle, Eye, Trash2 } from "lucide-react"
import { AddExpenseDialog } from "@/components/add-expense-dialog"
import { ViewExpensesDialog } from "@/components/view-expenses-dialog"
import { DeleteExpenseDialog } from "@/components/delete-expense-dialog"

interface ExpenseManagementProps {
  userId: string
}

export function ExpenseManagement({ userId }: ExpenseManagementProps) {
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Manage Expenses</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button className="w-full justify-start gap-2" onClick={() => setAddDialogOpen(true)}>
            <PlusCircle className="h-4 w-4" />
            Add Expense
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start gap-2 bg-transparent"
            onClick={() => setViewDialogOpen(true)}
          >
            <Eye className="h-4 w-4" />
            View Expenses
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start gap-2 bg-transparent"
            onClick={() => setDeleteDialogOpen(true)}
          >
            <Trash2 className="h-4 w-4" />
            Delete Expense
          </Button>
        </CardContent>
      </Card>

      <AddExpenseDialog open={addDialogOpen} onOpenChange={setAddDialogOpen} userId={userId} />
      <ViewExpensesDialog open={viewDialogOpen} onOpenChange={setViewDialogOpen} userId={userId} />
      <DeleteExpenseDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen} userId={userId} />
    </>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClient } from "@/lib/supabase/client"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from "recharts"
import { format, startOfMonth, endOfMonth, eachMonthOfInterval, startOfYear } from "date-fns"

interface MonthlyYearlyChartProps {
  userId: string
}

interface ChartData {
  period: string
  amount: number
}

export function MonthlyYearlyChart({ userId }: MonthlyYearlyChartProps) {
  const [monthlyData, setMonthlyData] = useState<ChartData[]>([])
  const [yearlyData, setYearlyData] = useState<ChartData[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setIsLoading(true)
    const supabase = createClient()

    const { data: expenses } = await supabase
      .from("expenses")
      .select("date, amount")
      .eq("user_id", userId)
      .order("date")

    if (expenses) {
      // Process monthly data (last 12 months)
      const now = new Date()
      const monthsAgo = new Date()
      monthsAgo.setMonth(now.getMonth() - 11)

      const months = eachMonthOfInterval({
        start: startOfMonth(monthsAgo),
        end: endOfMonth(now),
      })

      const monthlyTotals = months.map((month) => {
        const monthStart = startOfMonth(month)
        const monthEnd = endOfMonth(month)

        const total = expenses
          .filter((e) => {
            const expenseDate = new Date(e.date)
            return expenseDate >= monthStart && expenseDate <= monthEnd
          })
          .reduce((sum, e) => sum + Number(e.amount), 0)

        return {
          period: format(month, "MMM yyyy"),
          amount: total,
        }
      })

      setMonthlyData(monthlyTotals)

      // Process yearly data (last 5 years)
      const currentYear = now.getFullYear()
      const years = Array.from({ length: 5 }, (_, i) => currentYear - 4 + i)

      const yearlyTotals = years.map((year) => {
        const yearStart = startOfYear(new Date(year, 0, 1))
        const yearEnd = new Date(year, 11, 31)

        const total = expenses
          .filter((e) => {
            const expenseDate = new Date(e.date)
            return expenseDate >= yearStart && expenseDate <= yearEnd
          })
          .reduce((sum, e) => sum + Number(e.amount), 0)

        return {
          period: year.toString(),
          amount: total,
        }
      })

      setYearlyData(yearlyTotals)
    }

    setIsLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Spending Trends</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="monthly">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="yearly">Yearly</TabsTrigger>
          </TabsList>
          <TabsContent value="monthly">
            {isLoading ? (
              <div className="h-[400px] flex items-center justify-center text-muted-foreground">Loading data...</div>
            ) : monthlyData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" angle={-45} textAnchor="end" height={100} fontSize={12} />
                  <YAxis />
                  <Tooltip
                    formatter={(value: number) =>
                      new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(value)
                    }
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="amount"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    name="Total Spending"
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                No monthly data available
              </div>
            )}
          </TabsContent>
          <TabsContent value="yearly">
            {isLoading ? (
              <div className="h-[400px] flex items-center justify-center text-muted-foreground">Loading data...</div>
            ) : yearlyData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={yearlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="period" />
                  <YAxis />
                  <Tooltip
                    formatter={(value: number) =>
                      new Intl.NumberFormat("en-US", {
                        style: "currency",
                        currency: "USD",
                      }).format(value)
                    }
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="amount"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    name="Total Spending"
                    dot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                No yearly data available
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { formatCurrency } from "@/lib/utils"
import type { ExpenseWithCategory } from "@/lib/types"
import { format } from "date-fns"
import { Trash2 } from "lucide-react"

interface DeleteExpenseDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  userId: string
}

export function DeleteExpenseDialog({ open, onOpenChange, userId }: DeleteExpenseDialogProps) {
  const [expenses, setExpenses] = useState<ExpenseWithCategory[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    if (open) {
      fetchExpenses()
    }
  }, [open])

  const fetchExpenses = async () => {
    setIsLoading(true)
    const supabase = createClient()
    const { data } = await supabase
      .from("expenses")
      .select(`
        *,
        category:categories(*)
      `)
      .eq("user_id", userId)
      .order("date", { ascending: false })

    if (data) setExpenses(data as unknown as ExpenseWithCategory[])
    setIsLoading(false)
  }

  const handleDelete = async (expenseId: string) => {
    setDeletingId(expenseId)
    const supabase = createClient()

    try {
      const { error } = await supabase.from("expenses").delete().eq("id", expenseId)

      if (error) throw error

      setExpenses(expenses.filter((e) => e.id !== expenseId))
      router.refresh()
    } catch (error) {
      console.error("Error deleting expense:", error)
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Delete Expenses</DialogTitle>
          <DialogDescription>Select an expense to delete it permanently</DialogDescription>
        </DialogHeader>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Loading expenses...</div>
        ) : expenses.length > 0 ? (
          <div className="space-y-2">
            {expenses.map((expense) => (
              <div
                key={expense.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {expense.category && (
                      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: expense.category.color }} />
                    )}
                    <span className="font-medium">{expense.category?.name || "Uncategorized"}</span>
                  </div>
                  {expense.description && <p className="text-sm text-muted-foreground">{expense.description}</p>}
                  <p className="text-xs text-muted-foreground mt-1">{format(new Date(expense.date), "MMM dd, yyyy")}</p>
                </div>
                <div className="flex items-center gap-4">
                  <p className="font-bold">{formatCurrency(Number(expense.amount))}</p>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(expense.id)}
                    disabled={deletingId === expense.id}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">No expenses to delete</div>
        )}
      </DialogContent>
    </Dialog>
  )
}
